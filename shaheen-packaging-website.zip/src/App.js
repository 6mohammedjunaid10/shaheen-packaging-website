import { useCallback, useEffect, useState } from "react";
import Lenis from "lenis";
import { Toaster } from "sonner";
import "@/App.css";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Services from "@/components/Services";
import Portfolio from "@/components/Portfolio";
import Showcase from "@/components/Showcase";
import Manifesto from "@/components/Manifesto";
import Process from "@/components/Process";
import Quote from "@/components/Quote";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import MobileActionBar from "@/components/MobileActionBar";
import QuoteModal from "@/components/QuoteModal";

function App() {
  const [quoteOpen, setQuoteOpen] = useState(false);
  const openQuote = useCallback(() => setQuoteOpen(true), []);
  const closeQuote = useCallback(() => setQuoteOpen(false), []);

  useEffect(() => {
    const lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    window.__lenis = lenis;
    let raf;
    const loop = (t) => {
      lenis.raf(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      window.__lenis = null;
    };
  }, []);

  return (
    <div className="grain min-h-screen bg-ivory font-sans text-cocoa">
      <Header onQuote={openQuote} />
      <main>
        <Hero onQuote={openQuote} />
        <Marquee />
        <Services />
        <Portfolio />
        <Showcase />
        <Manifesto />
        <Process />
        <Quote onQuote={openQuote} />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
      <MobileActionBar onQuote={openQuote} />
      <QuoteModal open={quoteOpen} onClose={closeQuote} />
      <Toaster position="top-center" richColors />
    </div>
  );
}

export default App;
