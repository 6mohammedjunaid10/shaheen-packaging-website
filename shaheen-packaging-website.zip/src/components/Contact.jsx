import { Mail, MapPin, Phone } from "lucide-react";
import { BUSINESS, WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { Reveal, Eyebrow } from "./Reveal";

const ROWS = [
  { icon: Phone, label: "Phone", value: BUSINESS.phoneDisplay, href: BUSINESS.tel, testid: "contact-phone" },
  { icon: WhatsAppIcon, label: "WhatsApp", value: BUSINESS.phoneDisplay, href: WHATSAPP_URL, testid: "contact-whatsapp" },
  { icon: Mail, label: "Email", value: BUSINESS.email, href: BUSINESS.mailto, testid: "contact-email" },
  { icon: MapPin, label: "Location", value: BUSINESS.location, href: null, testid: "contact-location" },
];

const Contact = () => (
  <section id="contact" className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32" data-testid="contact-section">
    <div className="grid gap-14 lg:grid-cols-[1.1fr_1fr] lg:gap-20">
      <Reveal>
        <Eyebrow>Get In Touch</Eyebrow>
        <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-4xl lg:text-5xl" data-testid="contact-heading">
          Shaheen <em className="italic text-chocolate">Packaging</em>
        </h2>
        <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.3em] text-bark">
          Creative Printing & Packaging Solutions
        </p>

        <div className="mt-10 divide-y divide-champagne/20 border-y border-champagne/20">
          {ROWS.map((r) => {
            const Icon = r.icon;
            const inner = (
              <>
                <span className="grid h-11 w-11 shrink-0 place-items-center border border-champagne/40 text-chocolate">
                  <Icon className="h-4 w-4" />
                </span>
                <span>
                  <span className="block font-mono text-[10px] uppercase tracking-[0.28em] text-bark">{r.label}</span>
                  <span className="mt-1 block font-serif text-lg text-cocoa sm:text-xl">{r.value}</span>
                </span>
              </>
            );
            return r.href ? (
              <a
                key={r.label}
                href={r.href}
                target={r.href.startsWith("http") ? "_blank" : undefined}
                rel={r.href.startsWith("http") ? "noopener noreferrer" : undefined}
                data-testid={r.testid}
                className="flex items-center gap-5 py-5 transition-colors hover:bg-cream/70"
              >
                {inner}
              </a>
            ) : (
              <div key={r.label} data-testid={r.testid} className="flex items-center gap-5 py-5">
                {inner}
              </div>
            );
          })}
        </div>
      </Reveal>

      <Reveal delay={0.15} className="flex flex-col justify-center">
        <div className="border border-champagne/35 bg-cocoa p-8 shadow-float sm:p-10" data-testid="contact-actions-card">
          <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">Direct Lines</p>
          <h3 className="mt-3 font-serif text-2xl font-medium text-ivory sm:text-3xl">
            The fastest way to a quote is a <em className="italic text-champagne">conversation.</em>
          </h3>
          <div className="mt-8 flex flex-col gap-3.5">
            <a
              href={BUSINESS.tel}
              data-testid="contact-call-button"
              className="inline-flex items-center justify-center gap-2.5 border border-ivory/25 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:border-champagne hover:text-champagne"
            >
              <Phone className="h-4 w-4" /> Call Now
            </a>
            <a
              href={BUSINESS.mailto}
              data-testid="contact-email-button"
              className="inline-flex items-center justify-center gap-2.5 border border-ivory/25 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:border-champagne hover:text-champagne"
            >
              <Mail className="h-4 w-4" /> Email Us
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="contact-whatsapp-button"
              className="inline-flex items-center justify-center gap-2.5 bg-[#25D366] px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-white transition-colors duration-300 hover:bg-[#1eb85c]"
            >
              <WhatsAppIcon className="h-4 w-4" /> WhatsApp Us
            </a>
          </div>
          <p className="mt-6 text-center font-mono text-[10px] uppercase tracking-[0.24em] text-ivory/40">
            Replies within business hours · IST
          </p>
        </div>
      </Reveal>
    </div>
  </section>
);

export default Contact;
