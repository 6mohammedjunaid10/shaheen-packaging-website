import { motion } from "framer-motion";
import { WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";

const FloatingWhatsApp = () => (
  <motion.div
    initial={{ scale: 0, opacity: 0 }}
    animate={{ scale: 1, opacity: 1 }}
    transition={{ delay: 1.4, type: "spring", stiffness: 200, damping: 16 }}
    className="fixed bottom-[4.75rem] right-4 z-50 md:bottom-8 md:right-8"
  >
    <motion.a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with Shaheen Packaging on WhatsApp"
      data-testid="floating-whatsapp-button"
      animate={{ y: [0, -7, 0] }}
      transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.94 }}
      className="group relative grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-whatsapp md:h-16 md:w-16"
    >
      <span className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-25" aria-hidden />
      <WhatsAppIcon className="relative h-7 w-7 md:h-8 md:w-8" />
      <span className="pointer-events-none absolute right-full mr-4 hidden whitespace-nowrap border border-champagne/30 bg-cocoa px-4 py-2 font-mono text-[10px] uppercase tracking-[0.22em] text-ivory opacity-0 transition-opacity duration-300 group-hover:opacity-100 md:block">
        Get a quote on WhatsApp
      </span>
    </motion.a>
  </motion.div>
);

export default FloatingWhatsApp;
