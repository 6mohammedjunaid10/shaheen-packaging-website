import { ArrowUpRight } from "lucide-react";
import { BUSINESS, NAV_LINKS, WHATSAPP_URL, scrollToId } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { Logo } from "./Header";

const Footer = () => (
  <footer className="bg-cocoa text-ivory" data-testid="site-footer">
    <div className="mx-auto max-w-7xl px-5 pb-28 pt-16 sm:px-8 md:pb-16 lg:pt-20">
      <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <Logo onDark />
          <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">
            Creative Printing & Packaging Solutions
          </p>
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-ivory/60">
            {BUSINESS.location}
          </p>
        </div>

        <div>
          <h4 className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">Quick Links</h4>
          <ul className="mt-5 space-y-3">
            {NAV_LINKS.slice(1).map((l) => (
              <li key={l.href}>
                <button
                  type="button"
                  onClick={() => scrollToId(l.href)}
                  data-testid={`footer-link-${l.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className="text-sm text-ivory/70 transition-colors hover:text-champagne"
                >
                  {l.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">Contact</h4>
          <ul className="mt-5 space-y-3 text-sm text-ivory/70">
            <li>
              <a href={BUSINESS.tel} data-testid="footer-phone" className="transition-colors hover:text-champagne">
                {BUSINESS.phoneDisplay}
              </a>
            </li>
            <li>
              <a href={BUSINESS.mailto} data-testid="footer-email" className="break-all transition-colors hover:text-champagne">
                {BUSINESS.email}
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">WhatsApp</h4>
          <p className="mt-5 text-sm leading-relaxed text-ivory/60">
            The quickest way to discuss your requirement and get a quote.
          </p>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="footer-whatsapp-button"
            className="group mt-5 inline-flex items-center gap-2.5 border border-champagne/50 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:border-[#25D366] hover:bg-[#25D366]"
          >
            <WhatsAppIcon className="h-4 w-4" />
            Start a Conversation
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>
      </div>

      <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-champagne/20 pt-7 sm:flex-row">
        <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ivory/45" data-testid="footer-copyright">
          © 2026 Shaheen Packaging. All rights reserved.
        </p>
        <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ivory/45">
          Crafted in Hyderabad, India
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
