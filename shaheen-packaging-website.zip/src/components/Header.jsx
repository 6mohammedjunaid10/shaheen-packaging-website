import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { NAV_LINKS, scrollToId } from "../lib/site";
import { EASE } from "./Reveal";

export const Logo = ({ onDark = false }) => (
  <button
    type="button"
    onClick={() => scrollToId("#home")}
    data-testid="logo-home-link"
    className="flex items-center gap-3 text-left"
  >
    <span
      className={`grid h-11 shrink-0 place-items-center rounded-full px-2.5 ${
        onDark ? "bg-ivory/95" : ""
      }`}
    >
      <img src="/images/logo.png" alt="Shaheen Packaging logo" className="h-8 w-auto" />
    </span>
    <span className="leading-none">
      <span className={`block font-serif text-base font-semibold tracking-[0.18em] ${onDark ? "text-ivory" : "text-cocoa"}`}>
        SHAHEEN
      </span>
      <span className={`mt-1 block font-mono text-[9px] uppercase tracking-[0.42em] ${onDark ? "text-champagne" : "text-bark"}`}>
        Packaging
      </span>
    </span>
  </button>
);

const Header = ({ onQuote }) => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 48);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (href) => {
    setOpen(false);
    scrollToId(href);
  };

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: EASE }}
      className={`fixed inset-x-0 top-0 z-50 transition-[background-color,box-shadow,border-color] duration-500 ${
        scrolled
          ? "border-b border-champagne/25 bg-ivory/85 shadow-[0_10px_30px_-15px_rgba(43,22,13,0.15)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
      data-testid="site-header"
    >
      <div
        className={`mx-auto flex max-w-7xl items-center justify-between px-5 transition-[padding] duration-500 sm:px-8 ${
          scrolled ? "py-3" : "py-5"
        }`}
      >
        <Logo />
        <nav className="hidden items-center gap-8 lg:flex" data-testid="desktop-nav">
          {NAV_LINKS.map((l) => (
            <button
              key={l.href}
              type="button"
              onClick={() => go(l.href)}
              data-testid={`nav-${l.label.toLowerCase().replace(/\s+/g, "-")}`}
              className="group relative font-mono text-[11px] uppercase tracking-[0.22em] text-cocoa/80 transition-colors hover:text-chocolate"
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-champagne transition-[width] duration-300 group-hover:w-full" />
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onQuote}
            data-testid="header-quote-button"
            className="group hidden items-center gap-2 border border-cocoa bg-cocoa px-6 py-3 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:border-champagne hover:bg-champagne hover:text-cocoa sm:inline-flex"
          >
            Get a Quote
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
          <button
            type="button"
            onClick={() => setOpen(!open)}
            data-testid="mobile-menu-button"
            aria-label="Toggle menu"
            className="grid h-10 w-10 place-items-center border border-champagne/40 text-cocoa lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="overflow-hidden border-t border-champagne/25 bg-ivory/95 backdrop-blur-xl lg:hidden"
            data-testid="mobile-nav"
          >
            <div className="flex flex-col px-6 py-4">
              {NAV_LINKS.map((l) => (
                <button
                  key={l.href}
                  type="button"
                  onClick={() => go(l.href)}
                  data-testid={`mobile-nav-${l.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className="border-b border-champagne/15 py-4 text-left font-serif text-xl text-cocoa last:border-0"
                >
                  {l.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  onQuote();
                }}
                data-testid="mobile-nav-quote-button"
                className="mt-3 mb-2 inline-flex items-center justify-center gap-2 bg-cocoa px-6 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory"
              >
                Get a Quote <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

export default Header;
