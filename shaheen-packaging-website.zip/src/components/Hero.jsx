import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { EASE } from "./Reveal";

const LINES = ["Packaging That Makes", "Your Brand", "Unforgettable."];

const FloatLayer = ({ depth = 8, dur = 6, delay = 0, parallax, className, imgClassName, src, alt, testid }) => (
  <motion.div style={{ y: parallax }} className={`absolute ${className}`}>
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: 24 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 1.1, delay: 0.55 + delay, ease: EASE }}
    >
      <motion.img
        src={src}
        alt={alt}
        data-testid={testid}
        animate={{ y: [0, -depth, 0] }}
        transition={{ duration: dur, repeat: Infinity, ease: "easeInOut", delay }}
        className={`w-full border border-champagne/40 object-cover shadow-float ${imgClassName}`}
      />
    </motion.div>
  </motion.div>
);

const Hero = ({ onQuote }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const ySlow = useTransform(scrollYProgress, [0, 1], [0, 70]);
  const yMed = useTransform(scrollYProgress, [0, 1], [0, -60]);
  const yFast = useTransform(scrollYProgress, [0, 1], [0, -130]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section id="home" ref={ref} className="relative overflow-hidden pt-28 sm:pt-32 lg:pt-36" data-testid="hero-section">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 right-[-10%] h-[34rem] w-[34rem] rounded-full opacity-60"
        style={{ background: "radial-gradient(closest-side, rgba(182,154,99,0.22), transparent)" }}
      />
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 pb-16 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:gap-8 lg:pb-24">
        <motion.div style={{ opacity: fade }} className="relative z-10">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: EASE }}
            className="inline-flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.34em] text-bark"
            data-testid="hero-eyebrow"
          >
            <span className="h-px w-10 bg-champagne" />
            Shaheen Packaging
          </motion.p>

          <h1
            className="mt-6 font-serif text-4xl font-medium leading-[1.08] tracking-tight text-cocoa sm:text-5xl lg:text-6xl xl:text-7xl"
            data-testid="hero-headline"
          >
            {LINES.map((line, i) => (
              <span key={line} className="block overflow-hidden pb-1">
                <motion.span
                  className="block"
                  initial={{ y: "115%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 1, delay: 0.25 + i * 0.14, ease: EASE }}
                >
                  {i === 2 ? <em className="italic text-chocolate">{line}</em> : line}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.75, ease: EASE }}
            className="mt-6 max-w-md text-sm leading-relaxed text-bark sm:text-base"
            data-testid="hero-subtext"
          >
            Creative printing, premium packaging and professional design solutions crafted for
            businesses that want to stand out.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.9, ease: EASE }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <button
              type="button"
              onClick={onQuote}
              data-testid="hero-quote-button"
              className="group inline-flex items-center gap-2 bg-cocoa px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:bg-champagne hover:text-cocoa"
            >
              Get a Quote
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="hero-whatsapp-button"
              className="group inline-flex items-center gap-2.5 border border-cocoa/30 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-cocoa transition-colors duration-300 hover:border-[#25D366] hover:bg-[#25D366] hover:text-white"
            >
              <WhatsAppIcon className="h-4 w-4" />
              Chat on WhatsApp
            </a>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.15 }}
            className="mt-8 font-mono text-[10px] uppercase tracking-[0.28em] text-bark/70"
            data-testid="hero-location"
          >
            Hyderabad · Telangana · India
          </motion.p>
        </motion.div>

        <div className="relative mx-auto aspect-[4/5] w-full max-w-md sm:max-w-lg lg:max-w-none" data-testid="hero-composition">
          <FloatLayer
            src="/images/svc-cake-box.png" alt="Premium cake box" testid="hero-img-cake-box"
            className="right-0 top-0 z-10 w-[46%]" imgClassName="rounded-t-[10rem] rounded-b-2xl"
            parallax={yMed} depth={10} dur={7} delay={0.15}
          />
          <FloatLayer
            src="/images/svc-custom-packaging.png" alt="Luxury rigid box" testid="hero-img-luxury-box"
            className="left-0 top-[16%] z-20 w-[62%]" imgClassName="rounded-2xl"
            parallax={ySlow} depth={8} dur={6} delay={0.3}
          />
          <FloatLayer
            src="/images/svc-label.png" alt="Gold foil labels" testid="hero-img-label"
            className="right-[4%] top-[34%] z-30 w-[27%] rotate-3" imgClassName="rounded-xl"
            parallax={yFast} depth={12} dur={5} delay={0.45}
          />
          <FloatLayer
            src="/images/svc-carry-bag.png" alt="Premium carry bag" testid="hero-img-carry-bag"
            className="bottom-[4%] right-[6%] z-20 w-[42%]" imgClassName="rounded-2xl"
            parallax={yMed} depth={9} dur={6.5} delay={0.6}
          />
          <FloatLayer
            src="/images/svc-pouch.png" alt="Printed stand-up pouch" testid="hero-img-pouch"
            className="bottom-[10%] left-[2%] z-30 w-[32%] -rotate-2" imgClassName="rounded-xl"
            parallax={yFast} depth={11} dur={5.5} delay={0.75}
          />
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.5 }}
            className="absolute left-[6%] top-[4%] z-40 border border-champagne/40 bg-ivory/80 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.24em] text-chocolate backdrop-blur-md"
            data-testid="hero-tag-foil"
          >
            Gold Foil · Emboss
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.65 }}
            className="absolute bottom-[26%] right-[2%] z-40 border border-champagne/40 bg-cocoa/85 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.24em] text-champagne backdrop-blur-md"
            data-testid="hero-tag-custom"
          >
            Made to Order
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
