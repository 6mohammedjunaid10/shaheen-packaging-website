import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { WHY_POINTS } from "../lib/site";
import { Reveal, Eyebrow, EASE } from "./Reveal";

const Manifesto = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [50, -50]);

  return (
    <section id="why" ref={ref} className="bg-cocoa text-ivory" data-testid="why-section">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 sm:px-8 lg:grid-cols-[1fr_1.15fr] lg:gap-20 lg:py-32">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <Reveal>
            <Eyebrow dark>Why Shaheen</Eyebrow>
            <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.15] tracking-tight sm:text-4xl lg:text-5xl" data-testid="why-heading">
              More Than Printing.
              <br />
              We Build <em className="italic text-champagne">Brand Experiences.</em>
            </h2>
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-ivory/60">
              Every box, bag and label that leaves our floor carries your brand into a customer’s
              hands. We treat that responsibility like craft.
            </p>
          </Reveal>
          <motion.div style={{ y: imgY }} className="mt-10 hidden lg:block">
            <img
              src="/images/pf-jewelry-box.png"
              alt="Velvet rigid box crafted by Shaheen Packaging"
              loading="lazy"
              className="w-64 rounded-t-[8rem] rounded-b-xl border border-champagne/30 object-cover shadow-float"
              data-testid="why-image"
            />
          </motion.div>
        </div>

        <div>
          {WHY_POINTS.map((p, i) => (
            <motion.div
              key={p.num}
              initial={{ opacity: 0, y: 36 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.8, delay: i * 0.06, ease: EASE }}
              className="group flex gap-6 border-t border-champagne/20 py-8 transition-colors duration-500 first:border-t-0 first:pt-0 hover:bg-white/[0.03] sm:gap-10 lg:py-10"
              data-testid={`why-point-${p.num}`}
            >
              <span className="font-mono text-sm tracking-[0.2em] text-champagne">{p.num}</span>
              <div>
                <h3 className="font-serif text-2xl font-medium text-ivory transition-colors duration-300 group-hover:text-champagne sm:text-3xl">
                  {p.title}
                </h3>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-ivory/60">{p.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Manifesto;
