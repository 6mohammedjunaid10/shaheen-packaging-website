import { TRUST_ITEMS } from "../lib/site";

const Marquee = () => {
  const row = [...TRUST_ITEMS, ...TRUST_ITEMS];
  return (
    <div
      className="marquee-paused overflow-hidden border-y border-champagne/25 bg-cream/60 py-5"
      data-testid="trust-marquee"
    >
      <div className="animate-marquee flex w-max items-center">
        {[0, 1].map((half) => (
          <div key={half} className="flex items-center" aria-hidden={half === 1}>
            {row.map((item, i) => (
              <span
                key={`${half}-${i}`}
                className="flex items-center font-mono text-[11px] uppercase tracking-[0.34em] text-chocolate/80"
                data-testid={half === 0 ? `trust-item-${item.toLowerCase().replace(/\s+/g, "-")}` : undefined}
              >
                <span className="px-8">{item}</span>
                <span className="h-1.5 w-1.5 rotate-45 bg-champagne" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marquee;
