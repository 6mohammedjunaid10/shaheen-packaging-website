import { Phone, FileText } from "lucide-react";
import { BUSINESS, WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";

const MobileActionBar = ({ onQuote }) => (
  <div
    className="fixed inset-x-0 bottom-0 z-40 border-t border-champagne/30 bg-cocoa/95 backdrop-blur-lg md:hidden"
    data-testid="mobile-action-bar"
  >
    <div className="grid grid-cols-3">
      <a
        href={BUSINESS.tel}
        data-testid="mobile-call-button"
        className="flex flex-col items-center gap-1 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-ivory/90 transition-colors active:bg-white/5"
      >
        <Phone className="h-4 w-4" />
        Call
      </a>
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        data-testid="mobile-whatsapp-button"
        className="flex flex-col items-center gap-1 bg-[#25D366] py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-white transition-colors active:bg-[#1eb85c]"
      >
        <WhatsAppIcon className="h-4 w-4" />
        WhatsApp
      </a>
      <button
        type="button"
        onClick={onQuote}
        data-testid="mobile-quote-button"
        className="flex flex-col items-center gap-1 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-champagne transition-colors active:bg-white/5"
      >
        <FileText className="h-4 w-4" />
        Get Quote
      </button>
    </div>
  </div>
);

export default MobileActionBar;
