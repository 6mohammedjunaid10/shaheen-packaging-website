import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { PORTFOLIO, PORTFOLIO_CATS, waLink } from "../lib/site";
import { Reveal, Eyebrow, EASE } from "./Reveal";

const Portfolio = () => {
  const [cat, setCat] = useState("ALL");
  const items = cat === "ALL" ? PORTFOLIO : PORTFOLIO.filter((p) => p.cat === cat);

  return (
    <section id="work" className="border-y border-champagne/25 bg-cream/50" data-testid="portfolio-section">
      <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32">
        <div className="mb-12 text-center lg:mb-16">
          <Reveal>
            <div className="flex justify-center">
              <Eyebrow>Selected Work</Eyebrow>
            </div>
            <h2 className="mx-auto mt-4 max-w-3xl font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-4xl lg:text-5xl" data-testid="portfolio-heading">
              Designed to Be Seen. <em className="italic text-chocolate">Made to Be Remembered.</em>
            </h2>
          </Reveal>
        </div>

        <Reveal delay={0.1} className="mb-12 flex flex-wrap justify-center gap-2.5">
          {PORTFOLIO_CATS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCat(c)}
              data-testid={`filter-${c.toLowerCase()}`}
              className={`border px-5 py-2.5 font-mono text-[10px] uppercase tracking-[0.22em] transition-colors duration-300 ${
                cat === c
                  ? "border-cocoa bg-cocoa text-ivory"
                  : "border-champagne/40 bg-transparent text-bark hover:border-cocoa hover:text-cocoa"
              }`}
            >
              {c}
            </button>
          ))}
        </Reveal>

        <motion.div layout className="columns-1 gap-6 sm:columns-2 lg:columns-3" data-testid="portfolio-grid">
          <AnimatePresence mode="popLayout">
            {items.map((p) => (
              <motion.figure
                layout
                key={p.title}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.5, ease: EASE }}
                className="group relative mb-6 break-inside-avoid overflow-hidden border border-champagne/30 shadow-soft"
                data-testid={`portfolio-item-${p.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
              >
                <img
                  src={p.img}
                  alt={p.title}
                  loading="lazy"
                  className={`${p.ratio} w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]`}
                />
                <figcaption className="absolute inset-0 flex flex-col justify-end bg-cocoa/0 p-6 opacity-0 transition-all duration-500 group-hover:bg-cocoa/75 group-hover:opacity-100">
                  <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">{p.cat}</span>
                  <span className="mt-1.5 font-serif text-2xl text-ivory">{p.title}</span>
                  <a
                    href={waLink(`Hi Shaheen Packaging, I saw your ${p.title} and I’d like similar packaging for my brand. Please share a quote.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid={`portfolio-cta-${p.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                    className="mt-3 inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-ivory/90 transition-colors hover:text-[#25D366]"
                  >
                    Get Similar Packaging <ArrowUpRight className="h-3.5 w-3.5" />
                  </a>
                </figcaption>
              </motion.figure>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
