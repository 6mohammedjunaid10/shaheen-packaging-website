import { useRef } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { PROCESS_STEPS } from "../lib/site";
import { Reveal, Eyebrow, EASE } from "./Reveal";

const Process = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 75%", "end 60%"] });
  const lineScale = useSpring(scrollYProgress, { stiffness: 60, damping: 20 });

  return (
    <section id="process" ref={ref} className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32" data-testid="process-section">
      <div className="mb-14 text-center lg:mb-20">
        <Reveal>
          <div className="flex justify-center">
            <Eyebrow>How It Works</Eyebrow>
          </div>
          <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-4xl lg:text-5xl" data-testid="process-heading">
            From Brief to Box, <em className="italic text-chocolate">Beautifully Simple.</em>
          </h2>
        </Reveal>
      </div>

      <div className="relative">
        <div className="absolute left-[19px] top-0 h-full w-px bg-champagne/25 lg:left-0 lg:top-[26px] lg:h-px lg:w-full" aria-hidden />
        <motion.div
          style={{ scaleY: lineScale, scaleX: lineScale }}
          className="absolute left-[19px] top-0 h-full w-px origin-top bg-champagne lg:left-0 lg:top-[26px] lg:h-px lg:w-full lg:origin-left"
          aria-hidden
        />
        <div className="grid gap-12 lg:grid-cols-5 lg:gap-6">
          {PROCESS_STEPS.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.7, delay: i * 0.12, ease: EASE }}
              className="relative pl-14 lg:pl-0"
              data-testid={`process-step-${s.num}`}
            >
              <div className="absolute left-0 top-0 grid h-10 w-10 place-items-center rounded-full border border-champagne bg-ivory font-mono text-[11px] tracking-[0.15em] text-chocolate lg:relative lg:mx-0">
                {s.num}
              </div>
              <h3 className="mt-1 font-mono text-[11px] font-medium uppercase tracking-[0.24em] text-cocoa lg:mt-6">
                {s.title}
              </h3>
              <p className="mt-2.5 text-sm leading-relaxed text-bark">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;
