import { ArrowUpRight } from "lucide-react";
import { WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { Reveal, Eyebrow } from "./Reveal";

const Quote = ({ onQuote }) => (
  <section id="quote" className="border-y border-champagne/30 bg-cream/60" data-testid="quote-section">
    <div className="mx-auto flex max-w-7xl flex-col gap-10 px-5 py-24 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:py-32">
      <Reveal className="max-w-2xl">
        <Eyebrow>Let’s Begin</Eyebrow>
        <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-5xl lg:text-6xl" data-testid="quote-heading">
          Have a Packaging <em className="italic text-chocolate">Requirement?</em>
        </h2>
        <p className="mt-6 max-w-lg text-sm leading-relaxed text-bark sm:text-base">
          Tell us what you need. We’ll help you find the right printing, packaging and design
          solution — with honest pricing and realistic timelines.
        </p>
      </Reveal>
      <Reveal delay={0.15} className="flex flex-col gap-4 sm:flex-row lg:flex-col">
        <button
          type="button"
          onClick={onQuote}
          data-testid="quote-section-quote-button"
          className="group inline-flex items-center justify-center gap-2 bg-cocoa px-10 py-5 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:bg-champagne hover:text-cocoa"
        >
          Get a Quote
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </button>
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          data-testid="quote-section-whatsapp-button"
          className="inline-flex items-center justify-center gap-2.5 border border-cocoa/30 px-10 py-5 font-mono text-[11px] uppercase tracking-[0.22em] text-cocoa transition-colors duration-300 hover:border-[#25D366] hover:bg-[#25D366] hover:text-white"
        >
          <WhatsAppIcon className="h-4 w-4" />
          Chat on WhatsApp
        </a>
      </Reveal>
    </div>
  </section>
);

export default Quote;
