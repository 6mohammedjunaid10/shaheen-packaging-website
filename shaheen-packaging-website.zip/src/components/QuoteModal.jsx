import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, X } from "lucide-react";
import { toast } from "sonner";
import { SERVICES, waLink } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { EASE } from "./Reveal";

const CATEGORIES = [...SERVICES.map((s) => s.title), "Other"];

const QuoteModal = ({ open, onClose }) => {
  const [form, setForm] = useState({ name: "", phone: "", category: "Custom Packaging", message: "" });
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (open && window.__lenis) window.__lenis.stop();
    if (!open && window.__lenis) window.__lenis.start();
  }, [open]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      const res = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/leads`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      toast.success("Requirement received — we’ll reach out to you shortly.");
      setForm({ name: "", phone: "", category: "Custom Packaging", message: "" });
      onClose();
    } catch {
      toast.error("Couldn’t send right now — please try WhatsApp instead.");
    } finally {
      setSending(false);
    }
  };

  const waMessage = () =>
    `Hi Shaheen Packaging, I’m ${form.name || "a business owner"}. I’m interested in ${form.category}.${
      form.message ? ` ${form.message}` : ""
    } I’d like to discuss my requirement and get a quote.`;

  const inputCls =
    "w-full border border-champagne/40 bg-white/70 px-4 py-3.5 text-sm text-cocoa placeholder:text-bark/50 outline-none transition-colors focus:border-chocolate";

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-6" data-testid="quote-modal-root">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-cocoa/70 backdrop-blur-sm"
            data-testid="quote-modal-backdrop"
          />
          <motion.div
            initial={{ opacity: 0, y: 48 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 48 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="relative max-h-[92vh] w-full max-w-lg overflow-y-auto border border-champagne/40 bg-ivory p-7 shadow-float sm:p-9"
            data-testid="quote-modal"
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Close quote form"
              data-testid="quote-modal-close"
              className="absolute right-5 top-5 grid h-9 w-9 place-items-center border border-champagne/40 text-cocoa transition-colors hover:bg-cocoa hover:text-ivory"
            >
              <X className="h-4 w-4" />
            </button>

            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-bark">Request a Quote</p>
            <h3 className="mt-2 font-serif text-2xl font-medium text-cocoa sm:text-3xl">
              Tell us what you’re <em className="italic text-chocolate">planning.</em>
            </h3>

            <form onSubmit={submit} className="mt-7 flex flex-col gap-4" data-testid="quote-form">
              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  required
                  value={form.name}
                  onChange={set("name")}
                  placeholder="Your name"
                  data-testid="quote-form-name"
                  className={inputCls}
                />
                <input
                  required
                  value={form.phone}
                  onChange={set("phone")}
                  placeholder="Phone / WhatsApp"
                  data-testid="quote-form-phone"
                  className={inputCls}
                />
              </div>
              <select
                value={form.category}
                onChange={set("category")}
                data-testid="quote-form-category"
                className={inputCls}
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <textarea
                rows={4}
                value={form.message}
                onChange={set("message")}
                placeholder="Quantity, size, finish, timeline — anything helps."
                data-testid="quote-form-message"
                className={`${inputCls} resize-none`}
              />
              <button
                type="submit"
                disabled={sending}
                data-testid="quote-form-submit"
                className="group inline-flex items-center justify-center gap-2 bg-cocoa px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:bg-champagne hover:text-cocoa disabled:opacity-60"
              >
                {sending ? "Sending…" : "Send Requirement"}
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </form>

            <div className="my-5 flex items-center gap-4">
              <span className="h-px flex-1 bg-champagne/30" />
              <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-bark/70">or</span>
              <span className="h-px flex-1 bg-champagne/30" />
            </div>

            <a
              href={waLink(waMessage())}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="quote-form-whatsapp"
              className="inline-flex w-full items-center justify-center gap-2.5 border border-[#25D366]/60 px-8 py-4 font-mono text-[11px] uppercase tracking-[0.22em] text-[#128a43] transition-colors duration-300 hover:bg-[#25D366] hover:text-white"
            >
              <WhatsAppIcon className="h-4 w-4" />
              Continue on WhatsApp
            </a>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default QuoteModal;
