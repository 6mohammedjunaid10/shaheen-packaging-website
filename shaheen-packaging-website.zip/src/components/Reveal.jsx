import { motion } from "framer-motion";

export const EASE = [0.22, 1, 0.36, 1];

export const Reveal = ({ children, delay = 0, y = 32, className = "" }) => (
  <motion.div
    initial={{ opacity: 0, y }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-60px" }}
    transition={{ duration: 0.9, delay, ease: EASE }}
    className={className}
  >
    {children}
  </motion.div>
);

export const Eyebrow = ({ children, dark = false }) => (
  <span
    className={`inline-flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.3em] ${
      dark ? "text-champagne" : "text-bark"
    }`}
  >
    <span className="h-px w-8 bg-champagne" />
    {children}
  </span>
);
