import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { SERVICES, waLink } from "../lib/site";
import { Reveal, Eyebrow, EASE } from "./Reveal";

const Services = () => (
  <section id="services" className="mx-auto max-w-7xl px-5 py-24 sm:px-8 lg:py-32" data-testid="services-section">
    <div className="mb-14 flex flex-col gap-6 lg:mb-20 lg:flex-row lg:items-end lg:justify-between">
      <Reveal>
        <Eyebrow>What We Craft</Eyebrow>
        <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-4xl lg:text-5xl" data-testid="services-heading">
          Every Format Your Brand
          <br />
          <em className="italic text-chocolate">Could Ever Need.</em>
        </h2>
      </Reveal>
      <Reveal delay={0.15} className="max-w-sm">
        <p className="text-sm leading-relaxed text-bark">
          From a single bakery box to full retail packaging programmes — designed, printed and
          finished under one roof in Hyderabad.
        </p>
      </Reveal>
    </div>

    <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
      {SERVICES.map((s, i) => (
        <motion.article
          key={s.slug}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.8, delay: (i % 4) * 0.08, ease: EASE }}
          whileHover={{ y: -10 }}
          className="group flex flex-col border border-champagne/30 bg-cream/70 shadow-soft transition-shadow duration-500 hover:shadow-float"
          data-testid={`service-card-${s.slug}`}
        >
          <div className="overflow-hidden">
            <img
              src={s.img}
              alt={s.title}
              loading="lazy"
              className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
            />
          </div>
          <div className="flex flex-1 flex-col p-6">
            <span className="font-mono text-[10px] tracking-[0.3em] text-champagne">
              {String(i + 1).padStart(2, "0")}
            </span>
            <h3 className="mt-2 font-serif text-xl font-semibold text-cocoa">{s.title}</h3>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-bark">{s.desc}</p>
            <a
              href={waLink(`Hi Shaheen Packaging, I’m interested in your ${s.title}. I’d like to discuss my requirement and get a quote.`)}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`service-cta-${s.slug}`}
              className="mt-5 inline-flex items-center gap-2 border-t border-champagne/30 pt-4 font-mono text-[11px] uppercase tracking-[0.2em] text-chocolate transition-colors hover:text-[#1eb85c]"
            >
              Discuss Requirement
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </motion.article>
      ))}
    </div>
  </section>
);

export default Services;
