import { useRef } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import { SHOWCASE, WHATSAPP_URL } from "../lib/site";
import { WhatsAppIcon } from "./icons";
import { Reveal, Eyebrow } from "./Reveal";

const Showcase = () => {
  const trackRef = useRef(null);
  const scrollBy = (dir) => trackRef.current?.scrollBy({ left: dir * 380, behavior: "smooth" });

  return (
    <section id="about" className="overflow-hidden py-24 lg:py-32" data-testid="showcase-section">
      <div className="mx-auto mb-12 flex max-w-7xl items-end justify-between px-5 sm:px-8 lg:mb-16">
        <Reveal>
          <Eyebrow>The Collection</Eyebrow>
          <h2 className="mt-4 font-serif text-3xl font-medium leading-[1.12] tracking-tight text-cocoa sm:text-4xl lg:text-5xl" data-testid="showcase-heading">
            One Studio.
            <br />
            <em className="italic text-chocolate">Every Format.</em>
          </h2>
        </Reveal>
        <Reveal delay={0.15} className="hidden gap-3 sm:flex">
          <button
            type="button"
            onClick={() => scrollBy(-1)}
            data-testid="showcase-prev"
            aria-label="Scroll showcase left"
            className="grid h-12 w-12 place-items-center border border-champagne/40 text-cocoa transition-colors hover:bg-cocoa hover:text-ivory"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => scrollBy(1)}
            data-testid="showcase-next"
            aria-label="Scroll showcase right"
            className="grid h-12 w-12 place-items-center border border-champagne/40 text-cocoa transition-colors hover:bg-cocoa hover:text-ivory"
          >
            <ArrowRight className="h-4 w-4" />
          </button>
        </Reveal>
      </div>

      <div
        ref={trackRef}
        className="no-scrollbar flex snap-x snap-mandatory gap-6 overflow-x-auto px-5 pb-6 sm:px-8 lg:gap-8 lg:px-[max(2rem,calc((100vw-80rem)/2+2rem))]"
        data-testid="showcase-track"
      >
        {SHOWCASE.map((item, i) => (
          <motion.figure
            key={item.name}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: i * 0.06 }}
            className="group relative w-[270px] shrink-0 snap-start sm:w-[330px]"
            data-testid={`showcase-item-${item.name.toLowerCase().replace(/\s+/g, "-")}`}
          >
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 5 + i * 0.5, repeat: Infinity, ease: "easeInOut" }}
              className="relative overflow-hidden border border-champagne/35 shadow-soft transition-shadow duration-500 group-hover:shadow-float"
            >
              <img src={item.img} alt={item.name} loading="lazy" className="aspect-[4/5] w-full object-cover" />
              <figcaption className="absolute inset-0 flex flex-col justify-end bg-cocoa/0 p-6 opacity-0 transition-all duration-500 group-hover:bg-cocoa/70 group-hover:opacity-100">
                <span className="font-mono text-[10px] uppercase tracking-[0.28em] text-champagne">{item.cat}</span>
                <span className="mt-1 font-serif text-2xl text-ivory">{item.name}</span>
                <span className="mt-2 text-xs leading-relaxed text-ivory/80">{item.desc}</span>
              </figcaption>
            </motion.div>
            <span className="mt-4 block text-center font-mono text-[11px] uppercase tracking-[0.3em] text-bark">
              {item.name}
            </span>
          </motion.figure>
        ))}

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex w-[270px] shrink-0 snap-start flex-col items-start justify-center border border-champagne/40 bg-cocoa p-8 sm:w-[330px]"
          data-testid="showcase-cta-card"
        >
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-champagne">Custom Brief</span>
          <p className="mt-4 font-serif text-3xl leading-snug text-ivory">
            Need Something Custom? <em className="italic text-champagne">Let’s Talk.</em>
          </p>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            data-testid="showcase-whatsapp-button"
            className="mt-8 inline-flex items-center gap-2.5 border border-champagne/50 px-6 py-3.5 font-mono text-[11px] uppercase tracking-[0.22em] text-ivory transition-colors duration-300 hover:bg-[#25D366] hover:border-[#25D366]"
          >
            <WhatsAppIcon className="h-4 w-4" />
            Start on WhatsApp
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default Showcase;
